import { Component, OnInit } from '@angular/core';
import { ApiservicesService } from '../apiservices.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-singleproduct',
  templateUrl: './singleproduct.component.html',
  styleUrls: ['./singleproduct.component.css']
})
export class SingleproductComponent implements OnInit {
  products:any
  loading:boolean=true
  p: number = 1;
  products11:any
  singlepro:any
  proiid:any
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: true,
    navSpeed: 500,
    
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      900: {
        items: 5
      },
      1400: {
        items:5
      }
    },
 
  }
  constructor(private spinner: NgxSpinnerService,private _service: ApiservicesService, private router: Router,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.singlepro=this.route.snapshot.paramMap.get('id');

    this.spinner.show();

    
    this.spinner.show();
     this._service.proid(this.singlepro)
      .subscribe(
        data => {
         let res: any = data;
          this.proiid = res;
          this.loading=false
       
   });
    
   this._service.GetRelatedProducts(this.singlepro)
   .subscribe(
     data => {
      let res: any = data["items"]
   this.products11 = res;
  this.loading=false
 });

  }

}
