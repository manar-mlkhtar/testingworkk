import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http'
import { Observable, of, } from 'rxjs';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ApiservicesService {
  baseurl = 'https://api.trgatestore.com/api'

  constructor(private http: HttpClient) { }
   //produccts
        allproduccts(): Observable<any> {
          return this.http.get( this.baseurl +'/Product?pageNumber=1&pageSize=10&sortField=Id&sortOrder=Asc');
        }
  //produccts
  allproduccts2(): Observable<any> {
    return this.http.get( this.baseurl +'/Product?pageNumber=1&pageSize=18&sortField=Id&sortOrder=Asc');
  }
 //produccts
 allproduccts3(): Observable<any> {
  return this.http.get( this.baseurl +'/Product?pageNumber=1&pageSize=200&sortField=Id&sortOrder=Asc');
}

 //proid
 proid(Id: number): Observable<any> {
  return this.http.get(this.baseurl + '/Product/'+Id);
}
 //proid
 GetRelatedProducts(Id: number): Observable<any> {
  return this.http.get(this.baseurl + '/Product/GetRelatedProducts/'+Id);
}

 
}
