import { Component, OnInit } from '@angular/core';
import { ApiservicesService } from '../apiservices.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:any
  loading:boolean=true
  p: number = 1;
  constructor(private spinner: NgxSpinnerService,private _service: ApiservicesService, private router: Router) { }

  ngOnInit(): void {
    this.spinner.show();

    
    this._service.allproduccts3()
    .subscribe(
      data => {
       let res: any = data["items"]
    this.products = res;
    this.loading=false
  });

    


  }

}
