import { Component, OnInit } from '@angular/core';
import { ApiservicesService } from '../apiservices.service';
import { ActivatedRoute, Router } from '@angular/router';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products:any
  loading:boolean=true
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: true,
    navSpeed: 500,
    
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      900: {
        items: 5
      },
      1400: {
        items:5
      }
    },
 
  }
  constructor(private spinner: NgxSpinnerService,private _service: ApiservicesService, private router: Router) { }

  ngOnInit(): void {

    this.spinner.show();

    this._service.allproduccts()
    .subscribe(
      data => {
       let res: any = data["items"]
    this.products = res;
    this.loading=false

  });

    
  this._service.allproduccts2()
  .subscribe(
    data => {
     let res: any = data["items"]
  this.products = res;
});

  }

}
